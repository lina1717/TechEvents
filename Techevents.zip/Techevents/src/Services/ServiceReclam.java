  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import com.codename1.io.CharArrayReader;
import com.codename1.io.ConnectionRequest;
import com.codename1.io.JSONParser;
import com.codename1.io.NetworkEvent;
import com.codename1.io.NetworkManager;
import com.codename1.ui.events.ActionListener;
import Entite.Reclamation;
import com.codename1.l10n.SimpleDateFormat;
import com.codename1.messaging.Message;
import com.codename1.ui.Dialog;
import com.codename1.ui.Display;
import com.codename1.ui.util.Resources;
import gui.AffichageReclam;
import gui.HomeForm;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;



//port static javax.management.Query.value;


/**
 *
 * @author bhk
 */
public class ServiceReclam {
    int temp;

    public void ajoutReclam(Reclamation rec) {
          ConnectionRequest con = new ConnectionRequest();// création d'une nouvelle demande de connexion
          SimpleDateFormat tempss = new SimpleDateFormat("yyyy-MM-dd");
                String date = tempss.format(rec.getDate());

        String Url = "http://127.0.0.1:8000/client/Reclamations/new" +"?nom="+ rec.getNom() 
                +"&prenom=" + rec.getPrenom()
                +"&email="+rec.getEmail()
                        + "&text=" +rec.getText()
                       + "&date="+ rec.getDate()
                                +"&etat=" + rec.getEtat();
              //  +"&nbjaimes=" + rec.getNbJaimes();// création de l'URL
             
        System.out.println("L'URL est : : :" + Url);
        con.setUrl(Url);// Insertion de l'URL de notre demande de connexion

        con.addResponseListener((e) -> {
            String str = new String(con.getResponseData());//Récupération de la réponse du serveur
            System.out.println(str);//Affichage de la réponse serveur sur la console

        });
        NetworkManager.getInstance().addToQueueAndWait(con);// Ajout de notre demande de connexion à la file d'attente du NetworkManager
    
    }
    
    
    
    public ArrayList<Reclamation> parseListReclamationJson(String json) {

        ArrayList<Reclamation> listReclamations = new ArrayList<>();

        try {
            JSONParser j = new JSONParser();// Instanciation d'un objet JSONParser permettant le parsing du résultat json
            Map<String, Object> Reclamations = j.parseJSON(new CharArrayReader(json.toCharArray()));
                 System.out.println(Reclamations);
            List<Map<String, Object>> list = (List<Map<String, Object>>) Reclamations.get("root");
            for (Map<String, Object> obj : list) {
                Reclamation e = new Reclamation();
                 float id = Float.parseFloat(obj.get("id").toString());
                e.setId((int) id);
                   
              //    float id = Float.parseFloat(obj.get("id").toString());
                //   e.setId((int) id);
               //   float iduser = Float.parseFloat(obj.get("iduser").toString());
                 //   e.setIduser((int) iduser);
                
                e.setNom(obj.get("nom").toString());
                e.setPrenom(obj.get("prenom").toString());
                e.setEmail(obj.get("email").toString());
                e.setText(obj.get("text").toString());
  //       e.setNbJaimes((int) Float.parseFloat(obj.get("nbjaimes").toString()));
                 SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
                 String date = formater.format(e.getDate());   
              e.setDate((Date) obj.get(date));
            //  float etat = Float.parseFloat(obj.get("etat").toString());
         //     e.setEtat((int) etat);
               
                     
                   
                System.out.println(e);
                listReclamations.add(e);

            }

        } catch (IOException ex) {
        }
        
        /*
            A ce niveau on a pu récupérer une liste des tâches à partir
        de la base de données à travers un service web
        */
        System.out.println(listReclamations);
        return listReclamations;

    }
    
    
    ArrayList<Reclamation> listReclamations = new ArrayList<>();
    
    public ArrayList<Reclamation> getList2(){       
        ConnectionRequest con = new ConnectionRequest();
        con.setUrl("http://127.0.0.1:8000/client/Reclamations/all");  
        con.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                ServiceReclam ser = new ServiceReclam();
                listReclamations = ser.parseListReclamationJson(new String(con.getResponseData()));
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(con);
        return listReclamations;
    }

    
    
    
    
    
    
     public void modifierReclam(Reclamation ta) {
             ConnectionRequest con = new ConnectionRequest();
        String Url = "http://127.0.0.1:8000/client/Reclamations/update/" +  ta.getId()+"?nom=" + ta.getNom()
                 + "&prenom=" + ta.getPrenom()
                + "&email=" + ta.getEmail()
                + "&text=" + ta.getText()
                 + "&etat="+  ta.getEtat();
        con.setUrl(Url);

        con.addResponseListener((e) -> {
            String str = new String(con.getResponseData());
            System.out.println(str);
             Dialog.show("Succés", "Reclamation modifié", "ok", null);

             AffichageReclam a=new AffichageReclam();
      a.getF().show();
          
        });
        NetworkManager.getInstance().addToQueueAndWait(con);
        }
  
     
     /*   public  void ajoutmail() {
          ConnectionRequest con = new ConnectionRequest();
        String Url = "http://127.0.0.1:8012/client//Mail" ;
        con.setUrl(Url);

        con.addResponseListener((e) -> {
            String str = new String(con.getResponseData());
            System.out.println(str);
             Dialog.show("Succés", "Reclamation modifié", "ok", null);

             HomeForm a=new HomeForm();
         a.getF().show();
          
        });
        NetworkManager.getInstance().addToQueueAndWait(con);
        
}*/
     
     
       public ArrayList<Reclamation> listaa(String json) {
         
        ArrayList<Reclamation> listaa = new ArrayList<>();

        try {
            JSONParser j = new JSONParser();// Instanciation d'un objet JSONParser permettant le parsing du résultat json
            Map<String, Object> Reclamations = j.parseJSON(new CharArrayReader(json.toCharArray()));
                 System.out.println(Reclamations);
            List<Map<String, Object>> list = (List<Map<String, Object>>) Reclamations.get("root");
            
            for (Map<String, Object> obj : list) {
                Reclamation e = new Reclamation();
                 float id = Float.parseFloat(obj.get("id").toString());
                e.setId((int) id);      
                e.setNom(obj.get("nom").toString());
                e.setPrenom(obj.get("prenom").toString());
                e.setEmail(obj.get("email").toString());
                e.setText(obj.get("text").toString());
              e.setNbJaimes((int) Float.parseFloat(obj.get("nbjaimes").toString()));
                 SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
                 String date = formater.format(e.getDate());   
              e.setDate((Date) obj.get(date));
                System.out.println(e);
                listReclamations.add(e);
            }

        } catch (IOException ex) {
        }
        System.out.println(listaa);
        return listaa;

    }

       
}