/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import Entite.Reclamation;


import com.codename1.io.ConnectionRequest;
import com.codename1.io.NetworkManager;
import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.Form;
import Services.ServiceReclam;
import com.codename1.components.ImageViewer;
import com.codename1.components.InfiniteProgress;
import com.codename1.io.Log;
import com.codename1.io.NetworkEvent;
import com.codename1.ui.BrowserComponent;
import com.codename1.ui.Button;
import static com.codename1.ui.Component.RIGHT;
import com.codename1.ui.Container;
import com.codename1.ui.Display;
import com.codename1.ui.FontImage;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.TextArea;
import com.codename1.ui.TextField;
import com.codename1.ui.Toolbar;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.Style;
import com.codename1.ui.spinner.Picker;
import com.codename1.ui.util.Resources;
import com.codename1.ui.util.UIBuilder;






//import com.sun.org.apache.bcel.internal.generic.RET;


/**
 *
 * @author bhk
 */
public class AffichageReclam extends Form{
 public static Form f, form;
      //  Label iduser;
    Label nom;
        Label prenom;
        Label email;
        Label text;
        Label date;
        Label etat;
        Label jaim;
   //    Label jaimpas;
  
    public AffichageReclam() {
            Form hi = new Form("Hi World", BoxLayout.y());
              setTitle("Liste Reclamation"); 
       // f = new Form();
     //   lb = new SpanLabel("");
         Picker p = new Picker();
         ServiceReclam ser=new ServiceReclam();
           for (Reclamation ej : ser.getList2())
           {
           Container C1 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
           Label iduserR = new Label("iduser: " + ej.getIduser());
                Label nom = new Label("nom: " + ej.getNom());
               
                Label prenom = new Label("prenom: " + ej.getPrenom());
                Label email = new Label("email: " + ej.getEmail());
                Label text = new Label("text: " + ej.getText());
                Label date = new Label("date : " + ej.getDate());
             Label etat = new Label("etat : " + ej.getEtat());
                    Button btnn = new Button("Supprimer reclamation"); 
                  Button modifbtn = new Button("Modifier");
                      Button jaim = new Button("j'aime");
                   // Button jaimpas = new Button("j'aime pas");
               
                 
                
                       
                       
    btnn.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent o) {
                    Dialog d = new Dialog();
                    if (Dialog.show("Confirmation", "delete this reclamation??", "Ok", "Annuler")) {
                        ConnectionRequest req = new ConnectionRequest();
                        System.out.println("hellll");
                        req.setUrl("http://127.0.0.1:8000/client/Reclamations/supp/" + ej.getId()); 
                        NetworkManager.getInstance().addToQueue(req);
                        Dialog.show("Suppression", "Reclamation " 
                                + ej.getNom() + " a été supprimé avec succès!", "OK", null);
                   }  
                }
            });
                     
         modifbtn.addActionListener(new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent evt) {
             ConnectionRequest req = new ConnectionRequest();
               
                       modifbtn.addActionListener((ActionEvent e) -> {
                     ModifForm h = new ModifForm(ej);
                    h.getF().show();
                     //  });
                   
                        NetworkManager.getInstance().addToQueue(req);
                        Dialog.show("Modification", "La Reclamation de " 
                                + ej.getNom() + " a été modifié avec succès!", "OK", null);
                         });    
                     
             
                }               
           });     
         
    /*        private void addButton(Resources res, Reclamation eq,String title, boolean liked, int likeCount, int commentCount) {
        UIBuilder  ui = new UIBuilder();
          /*    Container ct1 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
         Container ct12;
         
         ct1.add(jaim);
         ct1.add(jaimpas);
             add(ct1);*/
    /*
       int height = Display.getInstance().convertToPixels(11.5f);
       int width = Display.getInstance().convertToPixels(14f);
       
       TextArea ta = new TextArea(title);
       ta.setUIID("NewsTopLine");
       ta.setEditable(false);
       Label v = new Label("              ");
    
       Label likes = new Label( eq.getNbJaimes()+ " j'aimes  ", "NewsBottomLine");
       likes.setTextPosition(RIGHT);
       if(!liked) {
           FontImage.setMaterialIcon(likes, FontImage.MATERIAL_RATE_REVIEW);
       } else {
           Style s = new Style(likes.getUnselectedStyle());
           s.setFgColor(0xff2d55);
           FontImage heartImage = FontImage.createMaterial(FontImage.MATERIAL_FAVORITE, s);
           likes.setIcon(heartImage);
       }*/
      /* Label comments = new Label(commentCount + " Comments", "NewsBottomLine");
       FontImage.setMaterialIcon(likes,FontImage.MATERIAL_RATE_REVIEW);*/
              
          // Label jaim = new Label("J'aime");
          Reclamation eq=new Reclamation();
      ///       Label jaimpas= new Label("J'aime pas");
             jaim.getAllStyles().setFgColor(0xFF0000);
          //   jaimpas.getAllStyles().setFgColor(0xFF0000);
           
             
       jaim.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent evt) {
                
            ConnectionRequest con1 = new ConnectionRequest();
               con1.setUrl("http://127.0.0.1:8014/client/LikeMobile/"+eq.getId());
                System.out.println(1);

            con1.addResponseListener(new ActionListener<NetworkEvent>() {

            @Override
            public void actionPerformed(NetworkEvent evt) {

            String x=new String(con1.getResponseData());
                System.out.println(new String(con1.getResponseData()));
                //int y= Integer.parseInt(x);
              int y=(int) Float.parseFloat(x);
                System.out.println("x est" +x);
            
                System.out.println("y est" +y);
      
                  if(x.equals("0"))
              {
                  boolean j;
                  j =Dialog.show("Mention j'aime", "Vous avez déjà effectué un j'aime sur ce produit ", "ok",null);

              }     
                  if(x.equals("1"))
              {
                  boolean j;
              
                  j =Dialog.show("Mention j'aime", "j'aime effectué ", "ok",null);

              }

            }
        });
        NetworkManager.getInstance().addToQueue(con1);
   

             
          }
            });
         
         
         
         
         
         
         
         
         
  /*          
  Button bbButton = new Button("Back");  
  bbButton.addActionListener(e -> {
  Dialog ip = new InfiniteProgress().showInifiniteBlocking();
  ip.dispose();
            
        
        });*/
                        /*    jaim.addPointerPressedListener(new ActionListener(){
           
            
           
          public void actionPerformed(ActionEvent evt) {
                
            ConnectionRequest con1 = new ConnectionRequest();
               con1.setUrl("http://localhost/madame/web/app_dev.php/pi_mobile/LikeMobile/"+authuser.user.getId()+"/"+eq.getId());
               
                System.out.println(1);

                
            con1.addResponseListener(new ActionListener<NetworkEvent>() {

            @Override
            public void actionPerformed(NetworkEvent evt) {

            String x=new String(con1.getResponseData());
                System.out.println(new String(con1.getResponseData()));
                //int y= Integer.parseInt(x);
              int y=(int) Float.parseFloat(x);
                System.out.println("x est" +x);
                System.out.println("y est" +y);
                
                
                  if(x.equals("0"))
              {
                  boolean j;
              
                  j =Dialog.show("Mention j'aime", "Vous avez déjà effectué un j'aime sur ce produit ", "ok",null);

              }
                       
                  if(x.equals("1"))
              {
                  boolean j;
              
                  j =Dialog.show("Mention j'aime", "j'aime effectué ", "ok",null);

              }

            }
        });
        NetworkManager.getInstance().addToQueue(con1);


             
          }
            });
              
               
          jaimpas.addPointerPressedListener(new ActionListener(){
           
            
           
          public void actionPerformed(ActionEvent evt) {
                
            ConnectionRequest con1 = new ConnectionRequest();
               con1.setUrl("http://localhost/madame/web/app_dev.php/pi_mobile/DislikeMobile/"+authuser.user.getId()+"/"+eq.getId());
                System.out.println("ok");
               

                
            con1.addResponseListener(new ActionListener<NetworkEvent>() {

            @Override
            public void actionPerformed(NetworkEvent evt) {
                 String x=new String(con1.getResponseData());
                System.out.println(new String(con1.getResponseData()));
   int y= Integer.parseInt(x);
              
                System.out.println("x est" +x);
                System.out.println("y est" +y);
    
                
                      if(x.equals("0"))
              {
                  boolean j;
              
                  j =Dialog.show("Mention j'aime pas", "Vous avez déjà effectué un j'aime pas sur ce produit ", "ok",null);

              }
                       
                  if(x.equals("1"))
              {
                  boolean j;
              
                  j =Dialog.show("Mention j'aime pas", "j'aime pas effectué ", "ok",null);

              }

            }
        });
        NetworkManager.getInstance().addToQueue(con1);


             
          }
            });
          
   
  
  
  
              Container cnt = new Container (new BoxLayout (BoxLayout.X_AXIS) );
               Container cnt1 = new Container (new BoxLayout (BoxLayout.Y_AXIS) );
             
            Label jaim = new Label("J'aime");
             Label jaimpas= new Label("J'aime pas");
         
             jaim.getAllStyles().setFgColor(0xFF0000);
             jaimpas.getAllStyles().setFgColor(0xFF0000);
     
             
             
             cnt.add(cnt1);  
            
           /*   f1.getToolbar().addCommandToLeftBar("back",null,new ActionListener<ActionEvent>() {
            @Override
            public void actionPerformed(ActionEvent evt) {
               ProduitForm produit=new ProduitForm(theme);
                produit.show();
            }
        });*/

    C1.add(nom);
    C1.add(prenom);
    C1.add(email);
    C1.add(text);
    C1.add(date);
  // C1.add(etat);
    C1.add(btnn);
    C1.add(modifbtn);
    C1.add(jaim);
  // C1.add(jaimpas);
  //C1.add(setnb);
          

    add(C1);
                }
    }
    
  public Form getF() {
        return f;
    }

    public void setF(Form f) {
        this.f = f;
    }
 
 
    
    
}
               
    //      jaimpas.addPointerPressedListener(new ActionListener(){
           
            /*
           
          public void actionPerformed(ActionEvent evt) {
                
            ConnectionRequest con1 = new ConnectionRequest();
               con1.setUrl("http://localhost/madame/web/app_dev.php/pi_mobile/DislikeMobile/"+authuser.user.getId()+"/"+eq.getId());
                System.out.println("ok");
               

                
            con1.addResponseListener(new ActionListener<NetworkEvent>() {

            @Override
            public void actionPerformed(NetworkEvent evt) {
                 String x=new String(con1.getResponseData());
                System.out.println(new String(con1.getResponseData()));
   int y= Integer.parseInt(x);
              
                System.out.println("x est" +x);
                System.out.println("y est" +y);
    
                
                      if(x.equals("0"))
              {
                  boolean j;
              
                  j =Dialog.show("Mention j'aime pas", "Vous avez déjà effectué un j'aime pas sur ce produit ", "ok",null);

              }
                       
                  if(x.equals("1"))
              {
                  boolean j;
              
                  j =Dialog.show("Mention j'aime pas", "j'aime pas effectué ", "ok",null);

              }

            }
        });
        NetworkManager.getInstance().addToQueue(con1);


             
          }
            });
*/
