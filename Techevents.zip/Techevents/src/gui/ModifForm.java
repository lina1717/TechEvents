/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import static com.codename1.charts.util.ColorUtil.CYAN;

import com.codename1.ui.Button;
import com.codename1.ui.Dialog;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.codename1.ui.util.Resources;
import Services.ServiceReclam;
import Entite.Reclamation;
import static com.codename1.charts.util.ColorUtil.BLUE;

import com.codename1.io.ConnectionRequest;
import static com.codename1.io.Log.e;
import com.codename1.io.NetworkManager;
import com.codename1.l10n.SimpleDateFormat;
import static com.codename1.push.PushContent.setTitle;
import com.codename1.ui.Container;
import com.codename1.ui.Label;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.spinner.Picker;

import static java.lang.Integer.parseInt;
import static java.lang.Double.parseDouble;
import java.util.Date;
import javafx.scene.paint.Color;


/**
 *
 * @author sana
 */
public class ModifForm   {

    Form f;
    TextField nom;
    TextField prenom;
    TextField email;
    TextField text;
  //  TextField etat;
  // TextField date;
    Button btnMod;
          //  btnAnnuler;

//    ModifForm(Event li, Resources res) {
//    }

    public  ModifForm( Reclamation ta) {
       f = new Form("Modifichhhhhhhhation");
        nom= new TextField(ta.getNom());
        nom.getAllStyles().setFgColor(BLUE);
        
        prenom= new TextField(ta.getPrenom());
        prenom.getAllStyles().setFgColor(BLUE);
        

        email= new TextField(ta.getEmail());
        email.getAllStyles().setFgColor(BLUE);
        
       text= new TextField(ta.getEmail());
       text.getAllStyles().setFgColor(BLUE);
        
   /*     etat= new TextField("etat:" +ta.getEtat());
        etat.getAllStyles().setFgColor(CYAN);*/
       //  SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
              //   String date = formater.format(ta.getDate());   
     //         ta.setDate((Date) get(date));
     
     
 //   date= new TextField(ta.getDate());
     //  date.getAllStyles().setFgColor(CYAN);
       
        btnMod = new Button("Modifier");
      //  btnAnnuler=new Button("Annuler");
        
        f.add(nom);
        f.add(prenom);
        f.add(email);
        f.add(text);
     //   f.add(etat);
 //     f.add(date);
        f.add(btnMod);
        
     //   f.add(btnAnnuler);
        btnMod.addActionListener((e) -> {
            ServiceReclam ser = new ServiceReclam();
           
            ta.setNom(nom.getText());
            ta.setPrenom(prenom.getText());
             ta.setEmail(email.getText());
             ta.setText(text.getText());
            
     //       ta.setEtat(Integer.parseInt(etat.getText()));
//            Event t = new Event( ttitre.getText(),
//                    tlieu.getText() ,
//                    Double.valueOf(tprix.getText()), 
//                   // Double.parseDouble(tprix.getText()),
//                    tdescription.getText(),     
//                    Integer.parseInt(tnbreticket.getText()));
//            //Event t = new Event( ttitre.getText(), tdescription.getText(), Double.parseDouble(tprix.getText()), tlieu.getText() ,Integer.parseInt(tnbreticket.getText()));

            System.out.println("9bal modif");
            
         ser.modifierReclam(ta);
            //  ModifForm h = new ModifForm(ta);
                //    h.getF().show();
            System.out.println("baad l modif");
//                        Dialog.show("Succés", "Evenement modifié", "ok", null);

            

        }); 
        
   //     btnAnnuler.addActionListener((e)->{
    //    Affichage a=new Affichage(res);
     //   a.getF().show();
  //      });
       // f.show();
        
    }


        /* 
              setTitle("mpo"); 
       // f = new Form();
     //   lb = new SpanLabel("");
         Picker p = new Picker();
         ServiceReclam ser=new ServiceReclam();
           for (Reclamation e : ser.getList2()) {
           Container C1 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
         //   Label iduserR = new Label("iduser: " + re.getIduser());
                Label nom = new Label("nom: " + e.getNom());
                Label prenom = new Label("prenom: " + e.getPrenom());
                Label email = new Label("email: " + e.getEmail());
                Label text = new Label("text: " + e.getText());
                Label date = new Label("date : " + e.getDate());
               Label etat = new Label("etat : " + e.getEtat());
                 
                    Button modifbtn = new Button("Modifier");
                   
                           
         modifbtn.addActionListener(new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent evt) {
             
                    if (Dialog.show("Confirmation", "update this reclamation??", "Ok", "Annuler")) {
                        ConnectionRequest req = new ConnectionRequest();
                        System.out.println("okayy");
                        req.setUrl("http://127.0.0.1:8000/client/Reclamations/update/" +  e.getId()+"?nom=" + e.getNom()
              + "&prenom=" + e.getPrenom()
                + "&email=" + e.getEmail()
                + "&text=" + e.getText()
             + "&etat="+  e.getEtat());
                           
                          modifbtn.addActionListener((ActionEvent e) -> {
                      ModifForm h = new ModifForm(ta, res);
                   ServiceReclam ser =new ServiceReclam();
                   ta.setNom(nom.getText());
                   ta.setPrenom(prenom.getText());
                   ta.setEmail(email.getText());
            ta.setText(text.getText());
            ta.setEtat(Integer.parseInt(etat.getText()));
              //    ser.modifierEvent(ta, res);
                 });
                        
                    
                        NetworkManager.getInstance().addToQueue(req);
                        Dialog.show("Modification", "Reclamation " 
                                + e.getNom() + " a été modifié avec succès!", "OK", null);
                   }  
                }               
           });     
            
           }}}

*/
    public Form getF() {
        return f;
    }

    public void setF(Form f) {
        this.f = f;
    }

    public TextField getNom() {
        return nom;
    }

    public void setNom(TextField nom) {
        this.nom = nom;
    }

    public TextField getPrenom() {
        return prenom;
    }

    public void setPrenom(TextField prenom) {
        this.prenom = prenom;
    }

    public TextField getEmail() {
        return email;
    }

    public void setEmail(TextField email) {
        this.email = email;
    }

    public TextField getText() {
        return text;
    }

    public void setText(TextField text) {
        this.text = text;
    }

   
    
    
}