/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import com.codename1.ui.Button;

import Services.ServiceReclam;
import Entite.Reclamation;
import static com.codename1.charts.util.ColorUtil.BLUE;
import static com.codename1.charts.util.ColorUtil.GREEN;
import com.codename1.ui.Container;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BoxLayout;

import com.codename1.l10n.SimpleDateFormat;
import com.codename1.messaging.Message;
import com.codename1.ui.Dialog;
import com.codename1.ui.Display;

import com.codename1.ui.Form;
import com.codename1.ui.Image;

import com.codename1.ui.TextField;
import com.codename1.ui.Toolbar;
import com.codename1.ui.spinner.Picker;
import com.codename1.ui.util.Resources;
import com.codename1.ui.validation.LengthConstraint;
import com.codename1.ui.validation.Validator;


/**
 *
 * @author bhk
 */
public class HomeForm {

    Form f;
    TextField Rnom;
    TextField Rprenom;
    TextField Remail;
    TextField Rtext;
    TextField Rdate;
    TextField Retat;
   //  TextField Rnb;
    Button btnajout,btnaff,btnmail;

    public HomeForm() {
    //     public ProduitForm(Resources res) {
      
         Validator v = new Validator();
            Form hi = new Form("Hi World", BoxLayout.y());
        f = new Form("Les Reclamations");

          
        Rnom = new TextField("","nom");
      Rnom.getAllStyles().setFgColor(BLUE);
         v.addConstraint(Rnom, new LengthConstraint(4));
                String testusername="^\\(?([a-z]{3})\\)?";
      
                
                
                
                
           
                
                
                
                
                
        Rprenom = new TextField("","prenom");
         Rprenom.getAllStyles().setFgColor(BLUE);
         
        Remail = new TextField("","email");
         Remail.getAllStyles().setFgColor(BLUE);
         
        Rtext = new TextField("","text");
        Rtext.getAllStyles().setFgColor(BLUE);
        
        Container dateContainer = new Container(new BoxLayout(BoxLayout.X_AXIS));
        Picker Rdate = new Picker();
        Label temp = new Label("date ");
        dateContainer.add(temp);
        dateContainer.add(Rdate);
         SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
       
        
        Retat = new TextField("","etat");
         Retat.getAllStyles().setFgColor(BLUE);
         
       //    Rnb= new TextField("","nbjaimes");
         
        btnajout = new Button("ajouter");
        btnajout.getAllStyles().setFgColor(GREEN);
        
        btnaff=new Button("Afficher");
         btnaff.getAllStyles().setFgColor(GREEN);
         
           btnmail=new Button("Mail");
        f.add( Rnom);
        f.add( Rprenom);
        f.add( Remail);
         f.add(Rtext);
      f.add(dateContainer);
         f.add(Retat);
        f.add(btnajout);
        f.add(btnaff);
         f.add(btnmail);
    btnmail.addActionListener((e) ->
    {
        
        Message m = new Message("<html><body>Check out <a href=\"https://www.codenameone.com/\">Codename One</a></body></html>");
m.setMimeType(Message.MIME_HTML);

// notice that we provide a plain text alternative as well in the send method
boolean success = m.sendMessageViaCloudSync("lina.sahli@esprit.tn", "lina.sahli@esprit.tn", "lina", "Message Subject",
                            "Check out Codename One at https://www.codenameone.com/");
        
       });
       
        btnajout.addActionListener((e) -> {
   
                ServiceReclam ser = new ServiceReclam();
           //       Reclamation t = new Reclamation();
       Reclamation t = new Reclamation(Rnom.getText(),Rprenom.getText(),Remail.getText(),Rtext.getText(),Rdate.getDate(), Integer.parseInt(Retat.getText()));
            ser.ajoutReclam(t);
         
         
              Dialog.show("felicitation", " votre reclamation a éte ajoute", "ok", null);       

            

        });
     btnaff.addActionListener((e)->{
      AffichageReclam a=new AffichageReclam();
       a.show();
     });
         
 
    }
    
    
    
    
    
  

    public Form getF() {
        return f;
    }

    public void setF(Form f) {
        this.f = f;
    }

    public TextField getRnom() {
        return Rnom;
    }

    public void setRnom(TextField Rnom) {
        this.Rnom = Rnom;
    }

       public TextField getRprenom() {
        return Rprenom;
    }

    public void setRprenom(TextField Rprenom) {
        this.Rprenom = Rprenom;
    }

    
       public TextField getRemail() {
        return Remail;
    }

    public void setRemail(TextField Remail) {
        this.Remail = Remail;
    }

    
    
    
       public TextField getRtext() {
        return Rtext;
    }

    public void setRtext(TextField Rnom) {
        this.Rtext = Rtext;
    }

    
    
       public TextField getRdate() {
        return Rdate;
    }

    public void setRdate(TextField Rdate) {
        this.Rdate = Rdate;
    }
    
       public TextField getRetat() {
        return Retat;
    }

    public void setRetat(TextField Retat) {
        this.Retat = Retat;
    }

public boolean isAEntier(String x) {
        try {
            Integer.parseInt(x);
        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }
}
