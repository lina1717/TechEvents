/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

import java.util.Date;
import java.util.Objects;

/**
 *
 * @author USER
 */
public class Reclamation {
    
   private int id;
   private int iduser;
   private String nom;
   private String prenom;
   private String email;
   private String text;
   private Date date;
   private Integer etat;
    private int NbJaimes;
  

    public Reclamation() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getEtat() {
        return etat;
    }

    public void setEtat(Integer etat) {
        this.etat = etat;
    }
        public int getNbJaimes() {
        return NbJaimes;
    }

    public void setNbJaimes(int NbJaimes) {
        this.NbJaimes = NbJaimes;
    }
    

    @Override
    public String toString() {
        return "Reclamation{" + "id=" + id + ", iduser=" + iduser + ", nom=" + nom + ", prenom=" + prenom + ", email=" + email + ", text=" + text + ", date=" + date + ", etat=" + etat + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Reclamation other = (Reclamation) obj;
        if (this.id != other.id) {
            return false;
        }
        if (this.iduser != other.iduser) {
            return false;
        }
        if (!Objects.equals(this.nom, other.nom)) {
            return false;
        }
        if (!Objects.equals(this.prenom, other.prenom)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.text, other.text)) {
            return false;
        }
        if (!Objects.equals(this.date, other.date)) {
            return false;
        }
        if (!Objects.equals(this.etat, other.etat)) {
            return false;
        }
        return true;
    }

    public Reclamation(int id, int iduser, String nom, String prenom, String email, String text, Date date, Integer etat) {
        this.id = id;
        this.iduser = iduser;
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.text = text;
        this.date = date;
        this.etat = etat;
    }

    public Reclamation(String nom, String prenom, String email, String text, Date date, Integer etat) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.text = text;
        this.date = date;
        this.etat = etat;
    }

    public Reclamation(String nom, String prenom, String email, String text, Integer etat) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.text = text;
        this.etat = etat;
    }

    public Reclamation(int id, int iduser, String nom, String prenom, String email, String text, Date date, Integer etat, int NbJaimes) {
        this.id = id;
        this.iduser = iduser;
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.text = text;
        this.date = date;
        this.etat = etat;
        this.NbJaimes = NbJaimes;
    }

    public Reclamation(String nom, String prenom, String email, String text, Date date, Integer etat, int NbJaimes) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.text = text;
        this.date = date;
        this.etat = etat;
        this.NbJaimes = NbJaimes;
    }

    
   
   
   
   
   
}
